# BATL
Bayesian annotations for targeted lipidomics: accurate identification of lipid species using LC-ESI-MS/MS in SRM/MRM modes 
