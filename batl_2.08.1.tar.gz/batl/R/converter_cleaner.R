convert_quantification_files <- function(filenames, vendor) {
    if (missing(filenames)) {
        stop(
            paste(
                "Must specify filenames",
                "which refers to the name(s) of the SRM/MRM quantification",
                "files."
            )
        )
    }
    if (!is.character(filenames)) {
        stop("filenames must be a string.")
    }
    if (missing(vendor)) {
        stop(
            paste(
                "Must specify the vendor format of your input dataset.",
                "Options are:\n",
                "'MultiQuant' from SCIEX\n",
                "'MassHunter' from Agilent\n",
                "'MassLynx' from Waters"
            )
        )
    }
    if (length(vendor) > 1) {
        stop("Must select a single vendor.")
    }
    strings <- c(
        "MultiQuant", "MassHunter", "MassLynx",
        "MultiQuant (SCIEX)", "MassHunter (Agilent)", "MassLynx (Waters)")
    if (!(vendor %in% strings)) {
        stop(
            paste(
                "Must specify the vendor format of your input dataset.",
                "Options are:\n",
                "'MultiQuant' from SCIEX\n",
                "'MassHunter' from Agilent\n",
                "'MassLynx' from Waters"
            )
        )
    }

    output <- vector("list", length(filenames))
    for (i in seq_along(filenames)) {
        output[[i]] <- tryCatch(
            {
                convert_to_batl_format(filenames[i], vendor, TRUE)[[1]]
            },
            error = function(e) {
                stop(
                    paste(
                        "File",
                        filenames[i],
                        "could not be converted.",
                        "Check whether the vendor format is correct for this",
                        "file and/or consider re-exporting the file to ensure",
                        "no typos/unwanted modifications have been introduced.",
                        "If the issue persists, please file a bug request at",
                        "ldomic@uottawa.ca."
                    )
                )
            }
        )
    }
    return(output)
}

possible_features <- function(data_list) {
    if (missing(data_list)) {
        stop(
            paste(
                "Must specify data_list.",
                "The data_list is a list of data frames of",
                "SRM/MRM quantification files."
            )
        )
    }
    if (!is.list(data_list)) {
        stop(
            paste(
                "Must specify data_list.",
                "The data_list is a list of data frames of",
                "SRM/MRM quantification files."
            )
        )
    }
    for (i in seq_along(data_list)) {
        if (!is.data.frame(data_list[[i]])) {
            stop(
                paste(
                    "The data_list elements must be a data frame."
                )
            )
        }
    }

    ## Find all numeric features shared across all datasets
    fnames <- vector("list", length = length(data_list))
    for (i in seq_along(data_list)) {
        select_idx_1 <- unlist(lapply(data_list[[i]], is.numeric))
        select_idx_2 <- unlist(lapply(data_list[[i]], function(x) !all(is.na(x))))
        select_idx_3 <- unlist(lapply(data_list[[i]], function(x) length(unique(x)) > 1))
        select_idx <- select_idx_1 & select_idx_2 & select_idx_3
        fnames[[i]] <- colnames(data_list[[i]][, ..select_idx])
    }
    fnames <- Reduce(intersect, fnames)
    fnames <- unique(c(fnames, "Relative RT", "Subtracted RT"))

    ## Remove some keyword 'features' that should not be used
    rfeatures <- c("Index", "Sample Index")
    fnames <- fnames[!(fnames %in% rfeatures)]

    ## Remove MultiQuant-specific 'features' that should not be used
    rfeatures_multiquant <- c("Vial Number", "Component Index")
    fnames <- fnames[!(fnames %in% rfeatures_m)]

    ## If 'Area' feature is present, replace it with Relative Area
    if ("Area" %in% fnames) {
        fnames[fnames %in% "Area"] <- "Relative Area"
    }

    ## If 'Height' feature is present, replace it with Relative Height
    if ("Height" %in% fnames) {
        fnames[fnames %in% "Height"] <- "Relative Height"
    }
    return(fnames)
}

possible_standards <- function(data_list) {

    if (missing(data_list)) {
        stop(
            paste(
                "Must specify data_list.",
                "The data_list is a list of data frames of",
                "SRM/MRM quantification files."
            )
        )
    }
    if (!is.list(data_list)) {
        stop(
            paste(
                "Must specify data_list.",
                "The data_list is a list of data frames of",
                "SRM/MRM quantification files."
            )
        )
    }
    strings <- c(
        "Lipid_identifier",
        "Lipid_identifier_MWBM",
        "Lipid_identifier_MAP_dup",
        "Lipid_identifier_MAP_nodup")
    counter <- c()
    for (i in seq_along(data_list)) {
        if (!any(colnames(data_list[[i]]) %in% strings)) {
            counter <- c(counter, i)
        }
    }
    if (length(counter) > 0) {
        stop(
            paste0(
                "The following datasets contained in data_list are not ",
                "labelled. ",
                "Please ensure there is a column called ",
                "'Lipid_identifier', ",
                "'Lipid_identifier_MWBM', ",
                "'Lipid_identifier_MAP_dup', or ",
                "'Lipid_identifier_MAP_nodup' ",
                "for dataset indices: ",
                paste(counter, collapse = ", "),
                "."
            )
        )
    }

    ## Bind all files together (they should all have the same columns)
    for (i in seq_along(data_list)) {
        setnames(
            data_list[[i]],
            "Lipid_identifier_MWBM",
            "Lipid_identifier",
            skip_absent = TRUE)
        setnames(
            data_list[[i]],
            "Lipid_identifier_MAP_dup",
            "Lipid_identifier",
            skip_absent = TRUE)
        setnames(
            data_list[[i]],
            "Lipid_identifier_MAP_nodup",
            "Lipid_identifier",
            skip_absent = TRUE)
    }

    ## Check that all lipid identity columns are filled out
    counter <- c()
    for (i in seq_along(data_list)) {
        if (all(is.na(data_list[[i]]$Lipid_identifier))) {
            counter <- c(counter, i)
        }
    }
    if (length(counter) > 0) {
        stop(
            paste0(
                "The Lipid_identifier column has not been ",
                "filled out for dataset indices: ",
                paste(counter, collapse = ", "),
                "."
            )
        )
    }
    output <- do.call("rbind", data_list)

    ## Get all lipid identifiers that are present in all samples
    output <- output[!is.na(Lipid_identifier)]
    output <- output[!(Lipid_identifier %in% c("", "UNASSIGNED"))]

    ## Find max number of samples and number of times each lipid identifier is
    ## observed
    id_count <- table(output[, Lipid_identifier])
    num_samples <- nrow(
        unique(output, by = c("Filename", "Sample Index", "Sample Name")))

    ## Get the lipid identifier/standards present in all samples
    permissible_standards <- names(which(id_count == num_samples))

    ##
    component_names <- vector("list", length = length(permissible_standards))
    for (i in seq_along(component_names)) {
        component_names[[i]] <- unique(
            output[
                Lipid_identifier == permissible_standards[i]
                , `Component Name`])
    }

    return(
        list(
            reference_standards = permissible_standards,
            reference_components = component_names))
}



build_training_set <- function(
    data_list, features, reference_identifier, exceptions) {

    if (missing(data_list)) {
        stop(
            paste(
                "Must specify data_list.",
                "The data_list is a list of data frames of",
                "SRM/MRM quantification files."
            )
        )
    }
    if (!is.list(data_list)) {
        stop(
            paste(
                "Must specify data_list.",
                "The data_list is a list of data frames of",
                "SRM/MRM quantification files."
            )
        )
    }
    for (i in seq_along(data_list)) {
        if (!is.data.frame(data_list[[i]])) {
            stop(
                paste(
                    "The data_list elements must be a data frame."
                )
            )
        }
    }
    if (missing(features)) {
        stop(
            paste(
                "Must specify peak features.",
                "Run |possible_features(data_list)| to check what features",
                "are available in your SRM/MRM peak quantification files."
            )
        )
    }
    if (missing(exceptions)) {
        exceptions <- NULL
    } else if (!is.character(exceptions)) {
        stop(
            paste(
                "The exceptions parameter must be a string or string vector.",
                "The exceptions refer to rows to remove in SRM/MRM peak",
                "quantification files stored in data_list.",
                "These rows to removed are identified based on the",
                "'Mass Info' column"
            )
        )
    }

    ##
    ## Features that require normalization
    fnorm <- c("Area", "Height", "Relative RT", "Subtracted RT")

    if (any(features %in% fnorm)) {
        if (missing(reference_standard)) {
            feat <- features[features %in% fnorm]
            stop(
                paste0(
                    "Must specify a reference_standard to normalize the ",
                    "following features:\n",
                    paste(feat, collapse = ", "),
                    ".\n",
                    "Run |possible_standards(data_list)| to get a list of ",
                    "all possible lipid_identifier that could be used as ",
                    "a reference standard."

                )
            )
        }
    }

    ## Keep retention time features anyways
    keep_rt <- c("Retention Time", "RT")

    ## Mandatory columns in this order
    keep_base <- c(
        "Filename",
        "Sample Index",
        "Sample Name",
        "Index",
        "Mass Info",
        "Component Name")

    ## Core features first then append custom features if there are any
    keep_features <- features

    ## Lipid identifier for each peak
    keep_identifier <- "Lipid_identifier"

    ## Get subtracted retention time constant from all input file
    subtract_constant <- compute_subtracted_rt(data_list)

    ## Features present in file that require normalization
    to_normalize <- fnorm[fnorm %in% features]

    for (i in seq_along(data_list)) {

        ## Get indices of all columns to keep
        keep_base_idx <- get_col_idx(data_list[[i]], keep_base)
        keep_features_idx <- get_col_idx(data_list[[i]], keep_features)
        keep_rt_idx <- get_col_idx(data_list[[i]], keep_rt)
        setnames(
            data_list[[i]],
            "Lipid_identifier_MWBM",
            "Lipid_identifier",
            skip_absent = TRUE)
        keep_identifier_idx <- get_col_idx(data_list[[i]], keep_identifier)
        keep_all_idx <- unique(
            c(keep_base_idx, keep_identifier_idx, keep_features_idx, keep_rt_idx))

        ## Keep columns of interest by reference
        data_list[[i]] <- data_list[[i]][, unique(keep_all_idx), with = FALSE]

        ## Update the index of the retention time column now that dimensions changed
        keep_rt_idx <- get_col_idx(data_list[[i]], keep_rt)
        rt_name <- colnames(data_list[[i]])[keep_rt_idx]

        ## Clean the training set for duplicates, empty transitions, and UNASSIGNED
        data_list[[i]] <- unique(
            data_list[[i]],
            by = c(
                "Filename",
                "Sample Index",
                "Sample Name",
                "Mass Info",
                "Lipid_identifier"))
        data_list[[i]] <- data_list[[i]][
            !(Lipid_identifier %in% c("UNASSIGNED", ""))]

        setnames(data_list[[i]], rt_name, "Feature_check_na")
        data_list[[i]] <- data_list[[i]][!is.na(Feature_check_na)]
        setnames(data_list[[i]], "Feature_check_na", rt_name)

        ## Remove exceptions based on Mass.Info
        data_list[[i]] <- data_list[[i]][!(`Mass Info` %in% exceptions)]

        ## Compute the normalized features and add them as columns
        setnames(data_list[[i]], "Sample Index", "Sample.Index")
        setnames(data_list[[i]], "Sample Name", "Sample.Name")
        data_list[[i]] <- nb_label_peaks_normalize_file(
            loaded = data_list[[i]],
            features = to_normalize,
            fnorm = to_normalize,
            qstandard = reference_identifier,
            qstandard_col = "Lipid_identifier",
            subtract_constant = subtract_constant)
        setnames(data_list[[i]], "Sample.Index", "Sample Index")
        setnames(data_list[[i]], "Sample.Name", "Sample Name")
    }

    ## Merge all files and set column orders (base, identifier, features)
    merged <- do.call("rbind", data_list)

    ## Clean the training set again for duplicates across individual files
    merged <- unique(
        merged,
        by = c(
            "Filename",
            "Sample Index",
            "Sample Name",
            "Mass Info",
            "Lipid_identifier"))

    ## Remove retention time feature (however named) if it was not a core feature
    if (!any(keep_rt %in% keep_features)) {
        keep_rt_idx <- get_col_idx(merged, keep_rt)
        merged[, colnames(merged)[keep_rt_idx] := NULL]
    }






}








