## Extract desired meta info row
nb_label_peaks_extract_row <- function(model_meta_info, string) {

    ## Extract decision string
    row_idx <- grep(paste0("# ", string), model_meta_info)
    row_string <- model_meta_info[row_idx]

    ## Convert to vector
    row_string <- gsub(".*<-", "", row_string)
    row_string <- gsub(".*\\(", "", row_string)
    row_string <- gsub("\\)*", "", row_string)
    row_string <- gsub("\\s+", "", row_string)
    row_string <- strsplit(row_string, ",")[[1]]

    return(row_string)
}

## Load filenames
nb_label_peaks_load <- function(filename) {
    filename <- fread(
        filename,
        header = TRUE,
        na.strings = "N/A",
        sep = "\t")
    colnames(filename) <- gsub("\\s+", ".", colnames(filename))

    ## Remove blank rows if these are somehow scanned in
    filename <- filename[!(apply(is.na(filename) | filename == "", 1, all)), ]

    return(filename)
}

## Remove any rows from Mass.Info column
nb_label_peaks_exceptions <- function(loaded, exceptions) {

    ## Null strategy to pass R CMD check
    Mass.Info <- NULL

    if (length(exceptions) > 0L) {
        lrow1 <- nrow(loaded)
        loaded <- loaded[!(Mass.Info %in% exceptions)]
        lrow2 <- nrow(loaded)
        lrow2 <- lrow1 - lrow2
        if (lrow2 != 0) {
            message(paste0(
                "Filtered ", lrow2, "/", lrow1,
                " rows based on the exceptions ",
                "parameter."))
        }
    }
    return(loaded)
}

nb_label_peaks_normalize_file <- function(
    loaded, features, fnorm, qstandard, qstandard_col, subtract_constant) {

    ## Null strategy to pass R CMD check
    Retention.Time <- Component_name <- Standard_norm <- Feature <- NULL
    Sample.Name <- RT <- NULL

    ## Only normalize specified features that actually require normalization
    feat_normalize <- features[which(features %in% fnorm)]

    ## Normalize the appropriate features
    for (kFeature in feat_normalize) {

        ## Initialize internal standard column
        loaded[, "Standard_norm" := NA_real_]

        ## Special cases for relative and subtracted RT
        if (kFeature == "Relative.RT") {
            if ("Retention.Time" %in% colnames(loaded)) {
                loaded[, (kFeature) := Retention.Time]
            } else if ("RT" %in% colnames(loaded)) {
                loaded[, (kFeature) := RT]
            }
        }
        if (kFeature == "Subtracted.RT") {
            if ("Retention.Time" %in% colnames(loaded)) {
                loaded[, (kFeature) := Retention.Time]
            } else if ("RT" %in% colnames(loaded)) {
                loaded[, (kFeature) := RT]
            }
        }

        setnames(loaded, kFeature, "Feature")
        setnames(loaded, qstandard_col, "Component_name")

        loaded[Component_name == qstandard, Standard_norm := Feature]
        loaded[
            , Standard_norm := Standard_norm[which(!(is.na(Standard_norm)))]
            , by = c("Sample.Index", "Sample.Name")]

        if (any(is.na(loaded[, Standard_norm]))) {
            stop(paste0(
                "Some peaks have no matching standard to ",
                "normalize by the indicated feature. Check sample(s):\n",
                paste0(
                    loaded[is.na(Standard_norm), Sample.Name],
                    collapse = "\n")))
        }

        if (kFeature != "Subtracted.RT") {
            loaded[, Feature := Feature / Standard_norm]
        } else if (kFeature == "Subtracted.RT") {
            loaded[, Feature := Feature - Standard_norm + subtract_constant]
        }

        setnames(loaded, "Feature", kFeature)
        setnames(loaded, "Component_name", qstandard_col)
        loaded[, "Standard_norm" := NULL]
    }
    return(loaded)
}

## Log-transform the same features as those in the model
nb_label_peaks_log_transform <- function(loaded, features, log_vector) {

    ## Null strategy to pass R CMD check
    Feature <- NULL

    for (kFeature in seq_along(features)) {

        if (log_vector[kFeature] == TRUE) {
            setnames(loaded, features[kFeature], "Feature")

            ## Natural logarithm to match model!
            loaded[, Feature := log(Feature)]

            setnames(loaded, "Feature", features[kFeature])
        }
    }

    return(loaded)
}

## Add Q1/Q3 tolerance columns
nb_label_peaks_q13_tolerance <- function(dt, tolerance) {

    ## Null strategy to pass R CMD check
    Mass.Info <- Q1 <- Q3 <- NULL

    if ("Mass.Info" %in% colnames(dt)) {
        dt[, c("Q1", "Q3") := tstrsplit(gsub("\\s+", "", Mass.Info), "/")]
    }
    dt[, Q1 := as.numeric(Q1)]
    dt[, Q3 := as.numeric(Q3)]
    dt[, "Q1.min" := Q1 - tolerance]
    dt[, "Q1.max" := Q1 + tolerance]
    dt[, "Q3.min" := Q3 - tolerance]
    dt[, "Q3.max" := Q3 + tolerance]

    return(dt)
}

nb_label_peaks_reshape_model <- function(nb_model_only) {

    ## Null strategy to pass R CMD check
    Posterior_cutoff <- NULL

    ## Isolate cutoffs
    cutoffs_only <- copy(nb_model_only)
    cutoffs_only <- cutoffs_only[, c("Q1", "Q3", "Posterior_cutoff")]
    cutoffs_only <- unique(cutoffs_only)
    cutoffs_only[, "Lipid_identifier" := "Lipid_identifier_NA"]
    cutoffs_only[, "Prior" := as.numeric(Posterior_cutoff)]
    cutoffs_only[, "Posterior_cutoff" := NULL]
    nb_model_only[, c("Posterior_cutoff") := NULL]
    nb_model_only <- rbindlist(list(nb_model_only, cutoffs_only), fill = TRUE)

    return(nb_model_only)
}

## Check that features in the model are present in the file
nb_label_peaks_check_features <- function(loaded, features){

    if (any(c("Relative.RT", "Subtracted.RT") %in% features)) {
        if (!any(c("Retention.Time", "RT") %in% colnames(loaded))) {
            stop(paste(
                "The 'Retention Time' or 'RT' must be present in the peak file",
                "to compute the 'Relative.RT' or 'Subtracted.RT' feature",
                "values."))
        }
        if_features <- features[
          !(features %in% c("Relative.RT", "Subtracted.RT"))]
    } else {
        if_features <- features
    }
    if (any(!(if_features %in% colnames(loaded)))) {
        not_present <- if_features[!(if_features %in% colnames(loaded))]
        stop(paste0(
            "Not all features in the model are contained in the peak file. ",
            "Check that the following features are present as column headers: ",
            paste0(not_present, collapse = ", ")))
    }
}

## Only keep important peak/feature columns for computations
nb_label_peaks_subset <- function(loaded, features, qstandard_col) {

    if ("RT" %in% colnames(loaded)) {
        retention_time_name <- "RT"
    } else if ("Retention.Time" %in% colnames(loaded)) {
        retention_time_name <- "Retention.Time"
    } else {
      retention_time_name <- ""
    }

    if (any("Subtracted.RT" %in% features || "Relative.RT" %in% features)) {
        sub_features <- features[
            !(features %in% c("Subtracted.RT", "Relative.RT"))]
        if (retention_time_name != "") {
          sub_features <- unique(c(retention_time_name, sub_features))
        } else {
          stop(paste0(
              "Retention.Time or RT feature not found in dataset to label. ",
              "Ensure this column is present to compute the normalized ",
              "retention time feature (Relative.RT or Subtracted.RT)"))
        }
    } else {
        sub_features <- features
    }
    ## Retention.Time must be present for Relative.RT and Subtracted.RT
    #if (any("Subtracted.RT" %in% features || "Relative.RT" %in% features)) {
    #    if ("Retention.Time" %in% features) {
    #      sub_features <- features[
    #        !(features %in% c("Subtracted.RT", "Relative.RT"))]
    #      sub_features <- unique(c("Retention.Time", sub_features))
    #    } else if ("RT" %in% features) {
    #      sub_features <- features[
    #        !(features %in% c("Subtracted.RT", "Relative.RT"))]
    #      sub_features <- unique(c("RT", sub_features))
    #    } else {
    #      sub_features <- retention_time_name
    #    }
    #} else {
    #    sub_features <- features
    #}

    if (qstandard_col == "") {
        keep_col <- c(
            "Index", "Sample.Index", "Sample.Name", "Mass.Info",
            sub_features)
    } else {
        keep_col <- c(
            "Index", "Sample.Index", "Sample.Name", "Mass.Info",
            qstandard_col, sub_features)
    }

    loaded <- loaded[, keep_col, with = FALSE]

    return(loaded)
}

## Find all matching peak-Lipid_identifiers between peak file and model
nb_label_peaks_matching <- function(loaded, nb_model_only, features) {

    ## Null strategy to pass R CMD check
    Q1.min <- Q1.max <- Q3.min <- Q3.max <- Q1 <- NULL

    load_idx <- which(colnames(loaded) %in% features)
    colnames(loaded)[load_idx] <- paste0(colnames(loaded)[load_idx], "_value")

    ## Find all matching lipids from model to loaded file based on Q1/Q3
    setkey(loaded, Q1.min, Q1.max, Q3.min, Q3.max)
    setkey(nb_model_only, Q1.min, Q1.max, Q3.min, Q3.max)

    overlap <- foverlaps(
        loaded,
        nb_model_only,
        type = "any",
        mult = "all",
        nomatch = NA)
    overlap <- overlap[!(is.na(Q1))]

    return(overlap)
}

nb_label_peaks_gaussian_likelihood <- function(overlap, feature_name) {

    ## Null strategy to pass R CMD check
    Variance <- Value <- Mean <- Likelihood <- NULL

    ## Get column names for manipulation
    feature_value <- paste0(feature_name, "_value")
    feature_mean <- paste0(feature_name, "_mean")
    feature_variance <- paste0(feature_name, "_variance")

    setnames(
        overlap,
        colnames(overlap)[which(colnames(overlap) == feature_value)],
        "Value")
    setnames(
        overlap,
        colnames(overlap)[which(colnames(overlap) == feature_mean)],
        "Mean")
    setnames(
        overlap,
        colnames(overlap)[which(colnames(overlap) == feature_variance)],
        "Variance")

    ## Calculate Gaussian likelihood function
    overlap[
        , "Likelihood" := (
            (1 / (sqrt(2 * pi * Variance))) *
                exp((-1 / 2) * ((Value - Mean)^2) / (Variance)))]

    ## Lipid standards normalized to themselves will return 'NaN'
    ## Set 'NaN' to likelihood of 1.
    overlap[is.nan(Likelihood), Likelihood := 1]

    ## Reset column names
    setnames(overlap, "Value", feature_value)
    setnames(overlap, "Mean", feature_mean)
    setnames(overlap, "Variance", feature_variance)
    setnames(overlap, "Likelihood", feature_name)

    return(overlap)
}

## Compute posterior probabilities
nb_label_peaks_posterior <- function(overlap, features) {

    ## Null strategy to pass R CMD check
    Posterior <- Not_detected <- Prior <- Missing_data <- NULL
    Lipid_identifier <- NULL
    Missing_likelihood <- Lipid_identifier_NA <- Index <- NULL

    ## Ensure data.table object
    overlap <- as.data.table(overlap)

    coerce_idx_1 <- which(colnames(overlap) %in% features)
    coerce_idx_2 <- which(colnames(overlap) == "Prior")
    coerce_idx <- c(coerce_idx_1, coerce_idx_2)

    ## Coerce all prior/likelihood columns to numerics
    for (kCol in as.integer(coerce_idx)) {
        set(
            overlap,
            j = kCol,
            value = as.numeric(overlap[[kCol]]))
    }

    ## Calculate unnormalized posteriors for every row in the data table
    ## based on the feature likelihood value column and the prior
    overlap[, "Posterior" := NA_real_]
    overlap[
        , Posterior := prod(.SD, na.rm = TRUE)
        , .SDcols = c(coerce_idx)
        , by = seq_len(nrow(overlap))]

    ## Get feature names with '.Value' at the end
    overlap_value_names <- paste0(features, "_value")

    ## If all feature '_value's are NA, set the posterior to NA because a
    ## peak was never even detected at that transition
    overlap[
        , "Not_detected" := all(is.na(.SD))
        , .SDcols = c(overlap_value_names)
        , by = seq_len(nrow(overlap))]
    overlap[Not_detected == TRUE, Posterior := NA_real_]

    ## If the prior probability is 0, the likelihood function cannot be
    ## evaluated so the posterior is set to NA as well
    overlap[, "Missing_data" := ifelse(Prior == 0, TRUE, FALSE)]
    overlap[
        Missing_data == TRUE
        , Posterior := NA_real_]
    overlap[, "Missing_data" := NULL]

    ## If a peak is detected but the likelihood function is NA, set the
    ## posterior to NA. (The prod function will ignore NA when multipying)
    ## Also make sure this only applies to real Lipid_identifiers so that the
    ## assignment points to Lipid_identifier_NA as the best possible match
    overlap[
        , "Lipid_identifier_NA" := ifelse(
            grepl("Lipid_identifier_NA", Lipid_identifier, fixed = TRUE)
            , TRUE, FALSE)]
    overlap[
        , "Missing_likelihood" := all(is.na(.SD))
        , .SDcols = c(features)
        , by = seq_len(nrow(overlap))]
    overlap[
        Missing_likelihood == TRUE & Not_detected == FALSE &
            Lipid_identifier_NA == FALSE
        , Posterior := NA_real_]
    overlap[
      , c("Missing_likelihood", "Lipid_identifier_NA", "Not_detected") := NULL]

    ## Unique-ify NA names for decision rules
    overlap[
      Lipid_identifier == "Lipid_identifier_NA"
      , Lipid_identifier := paste("NA", Index, sep = "_")]

    return(overlap)
}

## Merge BATL Lipid_identifiers with the input file
nb_label_peaks_merge_original <- function(loaded_original, overlap, decision) {

    ## Null strategy to pass R CMD check
    Index <- Sample.Index <- Sample.Name <- MAP_dup <- MAP_nodup <- NULL
    MWBM <- NULL

    ## Get original filename columns
    original_cols <- colnames(loaded_original)

    decision_col <- c("", "", "")

    ## Join Lipid_identifiers back to the original file
    setkey(loaded_original, Index, Sample.Index, Sample.Name)
    setkey(overlap, Index, Sample.Index, Sample.Name)
    if ("MAP_dup" %in% decision) {
        loaded_original <- merge(
            loaded_original,
            overlap[
                MAP_dup == TRUE & !(is.na(MAP_dup))
                , c(
                  "Index", "Sample.Index", "Sample.Name", "Lipid_identifier")],
            all.x = TRUE)
        setnames(
          loaded_original, "Lipid_identifier", "Lipid_identifier_MAP_dup")
        decision_col[1] <- "Lipid_identifier_MAP_dup"
    }
    if ("MAP_nodup" %in% decision) {
        loaded_original <- merge(
            loaded_original,
            overlap[
                MAP_nodup == TRUE & !(is.na(MAP_nodup))
                , c(
                  "Index", "Sample.Index", "Sample.Name", "Lipid_identifier")],
            all.x = TRUE)
        setnames(
          loaded_original, "Lipid_identifier", "Lipid_identifier_MAP_nodup")
        decision_col[2] <- "Lipid_identifier_MAP_nodup"
    }
    if ("MWBM" %in% decision) {
        loaded_original <- merge(
            loaded_original,
            overlap[
                MWBM == TRUE & !(is.na(MWBM))
                , c(
                  "Index", "Sample.Index", "Sample.Name", "Lipid_identifier")],
            all.x = TRUE)
        setnames(loaded_original, "Lipid_identifier", "Lipid_identifier_MWBM")
        decision_col[3] <- "Lipid_identifier_MWBM"
    }

    ## Ensure column order is preserved
    decision_col <- decision_col[decision_col != ""]
    original_cols <- c(original_cols, decision_col)
    setcolorder(loaded_original, original_cols)

    return(loaded_original)
}

## Main function to label peaks for a single filename
nb_label_peaks_with_model <- function(
    filename, nb_model_only, qstandard, qstandard_col, features, decision,
    tolerance, pseudocount, log_vector, subtract_constant, exceptions, fnorm) {

    ## Null strategy to pass R CMD check
    Lipid_identifier <- NULL

    ## Load filenames
    if (!is.list(filename)) {
      loaded <- nb_label_peaks_load(filename = filename)
    } else {
      loaded <- as.data.table(filename)
      colnames(loaded) <- gsub("\\s+", ".", colnames(loaded), perl = TRUE)

      ## Remove blank rows if these are somehow scanned in
      loaded <- loaded[!(apply(is.na(loaded) | loaded == "", 1, all)), ]
    }

    ## Copy input file to maintain exactly the same output + Lipid_identifier
    ## column
    loaded_original <- copy(loaded)

    ## Remove any Mass.Info rows based on exceptions
    loaded <- nb_label_peaks_exceptions(
        loaded = loaded, exceptions = exceptions)

    ## Return error if features in loaded are not contained in nb_model_only
    nb_label_peaks_check_features(loaded = loaded, features = features)

    ## Only keep columns defining a unique peak and corresponding features
    loaded <- nb_label_peaks_subset(
        loaded = loaded, features = features, qstandard_col = qstandard_col)

    ## Normalize features in the model that require normalization
    loaded <- nb_label_peaks_normalize_file(
        loaded = loaded, features = features, fnorm = fnorm,
        qstandard = qstandard, qstandard_col = qstandard_col,
        subtract_constant = subtract_constant)

    ## Log-transform features in the model that require transformation
    loaded <- nb_label_peaks_log_transform(
        loaded = loaded, features = features, log_vector = log_vector)

    ## Add Q1/Q3 tolerance columns to the file
    loaded <- nb_label_peaks_q13_tolerance(dt = loaded, tolerance = tolerance)

    ## Find all matching peak-Lipid_identifiers between peak file and model
    overlap <- nb_label_peaks_matching(
        loaded = loaded, nb_model_only = nb_model_only, features = features)

    ## Calculate Gaussian feature likelihood and add to return table
    for (kFeature in features) {
        overlap <- nb_label_peaks_gaussian_likelihood(
            overlap = overlap, feature_name = kFeature)
    }

    ## Compute unnormalized posterior probabilities (numerator)
    overlap <- nb_label_peaks_posterior(overlap = overlap, features = features)

    ## Decision rule for final peak-Lipid_identifier assignment
    if ("MAP_dup" %in% decision) {
        overlap <- decision_map_dup(return = overlap)
    }
    if ("MAP_nodup" %in% decision) {
        overlap <- decision_map_nodup(return = overlap)
    }
    if ("MWBM" %in% decision) {
        overlap <- decision_mwbm(return = overlap)
    }

    ## Convert Lipid_identifier_NA to 'Unassigned'
    overlap[
      grepl("NA_", Lipid_identifier, fixed = TRUE)
      , Lipid_identifier := "UNASSIGNED"]

    ## Assign labels to the original peak file
    loaded_original <- nb_label_peaks_merge_original(
        loaded_original = loaded_original,
        overlap = overlap,
        decision = decision)

    ## Reset header names (replace '.' with a single space)
    colnames(loaded_original) <- gsub(
        ".", " ", fixed = TRUE, colnames(loaded_original))

    return(loaded_original)
}
