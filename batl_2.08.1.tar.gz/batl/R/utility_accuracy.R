#' utility_accuracy
#'
#' @description Utility function to calculate binary accuracies and whether
#' a peak was correctly or uncorrectly unassigned to a lipid label.
#'
#' @usage
#' utility_accuracy(
#'     cv_results_all,
#'     decision)
#'
#' @param cv_results_all Cross validation assignments outputted from
#' \emph{estimate_cutoff}.
#' @param decision Algorithm used to assign lipid labels to peaks. Options are:
#' "MAP_dup", "MAP_nodup", and "MWBM". See \emph{See Also} for more information
#' on these decision algorithms.
#'
#' @return
#' Data table object of binary accuracies for naive Bayes models generated
#' from different feature combinations.
#'
#' @keywords internal
#'

utility_accuracy <- function(cv_results_all, decision) {

    ## Null strategy to pass R CMD check
    Lipid_identifier <- Lipid_identifier_true <- NULL
    Temp <- Posterior <- NULL
    Interest <- Index <- V1 <- No_detect <- `.Value` <- NULL
    Check <- `.GRP` <- NULL

    ## Copy data table
    cv_results_all <- copy(cv_results_all)

    ## Initialize output
    scores <- matrix(
        NA,
        nrow = 1,
        ncol = 7,
        dimnames = list(
            c(),
            c(
                "Decision",
                "True Prediction",
                "False Prediction",
                "No Prediction",
                "No Prediction (True)",
                "No Prediction (False)",
                "No Detection at Transition")))
    scores <- lapply(seq_along(decision), function(x) scores)
    names(scores) <- decision

    for (kDecision in seq_along(decision)) {

        ## Temporary rename decision rule column for data table manipulation
        temp_name <- colnames(cv_results_all)[
            which(colnames(cv_results_all) %in% decision[kDecision])]
        setnames(cv_results_all, temp_name, "Interest")

        ## Initialize a fold column if one doesn't exist
        if (!(any(colnames(cv_results_all) %in% "Fold"))) {
            cv_results_all[, "Fold" := 1L]
        }

        ## How many peaks are there (for error checking):
        total_peaks <- nrow(
            cv_results_all[, .GRP, by = c("Index", "Sample.Name", "Fold")])

        ## Column to check for cases where a peak is not assigned or assigned
        ## twice (error-checking)
        cv_results_all[, "Check" := 0L]

        ## Decision algorithm
        scores[[kDecision]][1, 1] <- temp_name

        ## Rename first feature value for manipulation
        idx_grep <- grep(".Value$", colnames(cv_results_all))[1]
        setnames(cv_results_all, colnames(cv_results_all)[idx_grep], ".Value")

        ## Separate transitions with no detected peaks and everything else
        ## Any peak with no feature value cannot be a detected peak
        cv_results_all[
            , "No_detect" := ifelse(all(is.na(`.Value`)), TRUE, FALSE)
            , by = c("Index", "Sample.Name", "Fold")]

        ## No peak detected
        scores[[kDecision]][1, 7] <- nrow(
            cv_results_all[
                No_detect == TRUE
                , .GRP, by = c("Index", "Sample.Name", "Fold")])
        cv_results_all[No_detect == TRUE, Check := Check + 1L]

        ## Filter off these peaks that have been assigned "no detection"
        cv_results_subset <- cv_results_all[Check == 0L]

        ## Number of correctly assigned lipid identifiers
        scores[[kDecision]][1, 2] <- sum(
            cv_results_subset[
                No_detect == FALSE
                , Lipid_identifier == Lipid_identifier_true &
                    !(is.na(`.Value`)) &
                    !(is.na(Posterior)) & Interest == TRUE]
            , na.rm = TRUE)

        cv_results_subset[
            No_detect == FALSE &
                Lipid_identifier == Lipid_identifier_true &
                !(is.na(`.Value`)) &
                !(is.na(Posterior)) & Interest == TRUE
            , Check := Check + 1L]

        ## EXPERIMENTAL STUFF TO FIGURE OUT ERRORS
        test <- cv_results_subset[
            , sum(Check) > 0
            , by = c("Index", "Sample.Name", "Fold")][
                V1 == TRUE]
        cv_results_subset <- merge(
            cv_results_subset,
            test,
            all.x = TRUE)
        cv_results_subset <- cv_results_subset[is.na(V1)]

        ## Number of incorrectly assigned lipid identifiers
        scores[[kDecision]][1, 3] <- sum(
            cv_results_subset[
                No_detect == FALSE
                , !(is.na(Lipid_identifier)) &
                    Lipid_identifier != Lipid_identifier_true &
                    !(is.na(Posterior)) & Interest == TRUE]
            , na.rm = TRUE)

        cv_results_subset[
            No_detect == FALSE &
                !(is.na(Lipid_identifier)) &
                Lipid_identifier != Lipid_identifier_true &
                !(is.na(Posterior)) & Interest == TRUE
            , Check := Check + 1L]

        ## EXPERIMENTAL STUFF TO FIGURE OUT ERRORS
        cv_results_subset[, V1 := NULL]
        test <- cv_results_subset[
            , sum(Check) > 0
            , by = c("Index", "Sample.Name", "Fold")][
                V1 == TRUE]
        cv_results_subset <- merge(cv_results_subset, test, all.x = TRUE)
        cv_results_subset <- cv_results_subset[is.na(V1)]

        ## No prediction (true)
        ## Check if any matches have Lipid_identifier == Lipid_identifier_true
        ## If not, check if NA was assigned with greatest posterior
        cv_results_subset[
            , "Temp" := ifelse(
                Lipid_identifier == Lipid_identifier_true, 1L, 0L)]
        cv_results_subset[is.na(Temp), Temp := 0]

        cv_results_subset[, V1 := NULL]
        test <- cv_results_subset[
            , sum(Temp) == 0
            , by = c("Index", "Sample.Name", "Fold")][V1 == TRUE]
        cv_results_subset <- merge(cv_results_subset, test, all.x = TRUE)
        scores[[kDecision]][1, 5] <- nrow(cv_results_subset[
            No_detect == FALSE &
            V1 == TRUE &
            is.na(Lipid_identifier) &
            Interest == TRUE])

        cv_results_subset[, V1 := NULL]
        test <- cv_results_subset[
            , sum(Temp) == 0
            , by = c("Index", "Sample.Name", "Fold")][V1 == TRUE]
        cv_results_subset <- merge(cv_results_subset, test, all.x = TRUE)
        cv_results_subset[
            No_detect == FALSE &
            V1 == TRUE &
            is.na(Lipid_identifier == TRUE) &
            Interest == TRUE, Check := Check + 1L]

        ## EXPERIMENTAL STUFF TO FIGURE OUT ERRORS
        cv_results_subset[, V1 := NULL]
        test <- cv_results_subset[
            , sum(Check) > 0
            , by = c("Index", "Sample.Name", "Fold")][V1 == TRUE]
        cv_results_subset <- merge(cv_results_subset, test, all.x = TRUE)
        cv_results_subset <- cv_results_subset[is.na(V1)]

        ## No prediction (false)
        ## Check if the correct Lipid_identifier == Lipid_identifier_true match
        ## exists (by index)
        ## If yes, check if NA was assigned with greatest posterior
        cv_results_subset[
            , "Temp" := ifelse(
                Lipid_identifier == Lipid_identifier_true, 1L, 0L)]
        cv_results_subset[is.na(Temp), Temp := 0]

        cv_results_subset[, V1 := NULL]
        test <- cv_results_subset[
            , sum(Temp) == 1
            , by = c("Index", "Sample.Name", "Fold")][V1 == TRUE]
        cv_results_subset <- merge(cv_results_subset, test, all.x = TRUE)
        scores[[kDecision]][1, 6] <- nrow(cv_results_subset[
            No_detect == FALSE &
            V1 == TRUE &
            is.na(Lipid_identifier) &
            Interest == TRUE])

        cv_results_subset[, V1 := NULL]
        test <- cv_results_subset[
            , sum(Temp) == 1
            , by = c("Index", "Sample.Name", "Fold")][V1 == TRUE]
        cv_results_subset <- merge(cv_results_subset, test, all.x = TRUE)
        cv_results_subset[
            No_detect == FALSE &
            V1 == TRUE &
            is.na(Lipid_identifier == TRUE) &
            Interest == TRUE, Check := Check + 1L]

        ## EXPERIMENTAL STUFF TO FIGURE OUT ERRORS
        cv_results_subset[, V1 := NULL]
        test <- cv_results_subset[
            , sum(Check) > 0
            , by = c("Index", "Sample.Name", "Fold")][
                V1 == TRUE]
        cv_results_subset <- merge(cv_results_subset, test, all.x = TRUE)
        cv_results_subset <- cv_results_subset[is.na(V1)]

        ## Updated (these are the remaining correct unassignments)
        scores[[kDecision]][1, 5] <- as.numeric(unlist(
            scores[[kDecision]][1, 5])) +
            nrow(unique(
                cv_results_subset[Check == 0],
                by = c("Index", "Sample.Name", "Fold")))

        ## Total no prediction (true + false)
        scores[[kDecision]][1, 4] <- as.numeric(scores[[kDecision]][1, 5]) +
            as.numeric(scores[[kDecision]][1, 6])

        ## Peaks assigned by my function
        empirical_total <- suppressWarnings(sum(as.numeric(unlist(
            scores[[kDecision]][, c(2:4, 7)])), na.rm = TRUE))

        if (total_peaks != empirical_total) {
            message(paste0(
                temp_name,
                " total peaks=",
                total_peaks,
                ". Assigned peaks=",
                empirical_total
            ))
            #stop(paste0(
            #    "The |utility_accuracy| function is not working ",
            #    "properly with the |nb| output. Total detected/undetected ",
            #    "peaks does not equal the number of cases."))
        }

        ## Reset decision algorithm name
        setnames(cv_results_all, "Interest", temp_name)
    }

    ## Convert list to flattened matrix
    scores <- do.call("rbind", scores)

    return(scores)
}
