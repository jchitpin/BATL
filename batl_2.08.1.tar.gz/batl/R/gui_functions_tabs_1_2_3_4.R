# HELPER FUNCTIONS FOR VENDOR COMPATIBILITY --------------------------------------------------------
# LIST OF MASS SPECTROMETRY VENDORS =================================
## These are the exact names used for the radio buttons in the GUI
all_gui_radio_options <- function() {
  radio_values <- c(
    "MultiQuant (SCIEX)",
    "MassHunter (Agilent)",
    "MassLynx (Waters)"
  )
  return(radio_values)
}

## Initialize scores for each vendor plus the predicted vendor based on scores
initialize_vendor_scores <- function() {
  scores <- list(
    `multiquant` = 0L,
    `masshunter` = 0L,
    `masslynx` = 0L,
    prediction = NULL
  )
  return(scores)
}

## All MultiQuant columns when naively loading it with fread()
vendor_format_multiquant <- function() {
  all_columns <- c(
    "Index",                    "Sample Index",            "Original Filename",
    "Sample Name",              "Sample ID",               "Sample Comment",
    "Sample Type",              "Acquisition Date & Time", "Rack Number",
    "Plate Number",             "Vial Number",             "Dilution Factor",
    "Injection Volume",         "Operator Name",           "Acq. Method Name",
    "IS",                       "Component Name",          "Component Index",
    "Component Comment",        "IS Comment",              "Mass Info",
    "IS Mass Info",             "IS Name",                 "Component Group Name",
    "Conc. Units",              "Failed Query",            "IS Failed Query",
    "Outlier Reasons",          "Peak Comment",            "IS Peak Comment",
    "Actual Concentration",     "IS Actual Concentration", "Concentration Ratio",
    "Expected RT",              "IS Expected RT",          "Integration Type",
    "IS Integration Type",      "Area",                    "IS Area",
    "Corrected Area",           "IS Corrected Area",       "Area Ratio",
    "Height",                   "IS Height",               "Corrected Height",
    "IS Corrected Height",      "Height Ratio",            "Area / Height",
    "IS Area / Height",         "Corrected Area/Height",   "IS Corrected Area/Height",
    "Region Height",            "IS Region Height",        "Quality",
    "IS Quality",               "Retention Time",          "IS Retention Time",
    "Start Time",               "IS Start Time",           "End Time",
    "IS End Time",              "Total Width",             "IS Total Width",
    "Width at 50%",             "IS Width at 50%",         "Signal / Noise",
    "IS Signal / Noise",        "Baseline Delta / Height", "IS Baseline Delta / Height",
    "Modified",                 "Relative RT",             "Used",
    "Calculated Concentration", "Accuracy",                "Start Time at 5%",
    "End Time at 5%",           "Width at 5%",             "Start Time at 10%",
    "End Time at 10%",          "Width at 10%",            "Slope of Baseline",
    "Tailing Factor",           "Asymmetry Factor",        "Ion Ratio",
    "Expected Ion Ratio",       "Points Across Baseline",  "Points Across Half Height"
  )
  return(all_columns)
}

## All MassHunter files start with this exact column when naively loading it with fread()
vendor_format_masshunter <- function() {
  all_columns <- c("Compound.Method")
  return(all_columns)
}

## All MassLynx columns when naively loading it with fread()
vendor_format_masslynx <- function() {
  all_columns <- c("Quantify", "Compound", "Summary", "Report")
  return(all_columns)
}

# HELPER FUNCTIONS FOR LOADING FILES --------------------------------------------------------
# UNZIPPING INPUT FILES IF NECESSARY =================================
## file refers to the filepath of a text file to load like "/file.txt" or "/file.zip"
#' unzip_files
#'
#' @export unzip_files
#'
unzip_files <- function(file) {
  if (all(grepl(".zip$", file, perl = TRUE))) {
    return(unzip(file, exdir = normalizePath(dirname(file))))
  } else {
    return(file)
  }
}

# PREDICTING VENDOR FORMAT ------------------------------------------------
## Main function that takes a file path of an input text file or zip of files
## Loads column headers of the files, compares them to each vendor, and
## predicts the most appropriate vendor with at least 1 matching column
# file refers to the filepath of the text file
#' predict_vendor_format
#'
#' @export predict_vendor_format
#'
predict_vendor_format <- function(file) {

  ## Initialize vendor format names
  gui_radio_options <- all_gui_radio_options()

  ## Unzip file if necessary; otherwise nothing happens
  files <- unzip_files(file)

  ## Compute vendor format scores across all input text files and
  scores <- compute_format_scores(files)

  ## Return vendor predicted by the scores
  return(as.character(unlist(scores[4,1])))
}

## 'Naively' load the file with open.xlsx if it looks like a spreadsheet
## or with fread(). The point is to get the column names from this scanning.
load_file_naively <- function(file) {
  if (grepl(".xlsx$", file, perl = TRUE)) {
    return(read.xlsx(file))
  } else {
    return(fread(file, nrows = 10L, fill = TRUE, header = TRUE))
  }
}

## Binary/1-0 scoring system based on exact matching of colum names to those
## listed under the helper functions
compute_format_score_helper <- function(df, vendor_columns) {
  return(sum(!is.na(match(unique(colnames(df)), vendor_columns))) / length(vendor_columns))
}

## Loops over each vendor and computes the 1-0 score based on matching column names
compute_format_scores <- function(files) {

  ## Load vendor-specific columns to check for
  columns_multiquant <- vendor_format_multiquant()
  columns_masshunter <- vendor_format_masshunter()
  columns_masslynx <- vendor_format_masslynx()

  ## Load and predict the vendor format for each file
  scores <- initialize_vendor_scores()
  scores <- replicate(n = length(files), expr = scores)
  for (i in seq_along(files)) {
    df <- load_file_naively(files[i])

    ## Assign 0-1 score for every matching column name to each vendor format and
    ## normalize by total number of columns in the vendor format
    scores[1, i] <- compute_format_score_helper(df, vendor_format_multiquant())
    scores[2, i] <- compute_format_score_helper(df, vendor_format_masshunter())
    scores[3, i] <- compute_format_score_helper(df, vendor_format_masslynx())

    ## Prediction is vendor with the greatest score
    if (!all(as.numeric(unlist(scores[1:3, i])) == 0)) {
      scores[4, i] <- all_gui_radio_options()[
        as.numeric(which(unlist(scores[, i]) == max(unlist(scores[, i]))))]
    }
  }
  return(scores)
}

# SANITIZING TAB 1 INPUT FILES  =================================
## Please uncomment the return() with pasted text and remove the placeholders
## when using this with popups instead of renderPrint
#' sanitize_vendor_format
#'
#' @export sanitize_vendor_format
#'
sanitize_vendor_format <- function(file) {

  ## Unzip file if necessary
  files <- unzip_files(file)

  ## Check file extension and return error
  for (i in seq_along(files)) {
    if (grepl(".txt|.csv|.tsv|.xlsx$", files[i], perl = TRUE) == FALSE) {
      #return(
      #  paste(
      #    "Uploaded file or files in .zip must end with a",
      #    ".txt, .csv, .tsv, or .xlsx extension."
      #  )
      #)
      return(1L) # validation error message for incorrect file extension
    }
  }

  ## Predict the vendor format and check all files come from the same vendor
  scores <- compute_format_scores(files)
  if (!all(unlist(scores[4,]) == scores[4, 1])) {
    #return(
    #  paste(
    #    "Uploaded files in .zip must be in the same vendor.",
    #    "Check all files come from the same vendor-specific software program."
    #  )
    #)
    return(2L) # validation error message that files come from different vendors
  }
  return(0L) # no errors
}

#' sanitize_input_columns
#'
#' @export sanitize_input_columns
#'
sanitize_input_columns <- function(filepath, vendor) {

  ## Mandatory MultiQuant columns (before running |load_multiquant|)
  mandatory_multiquant <- c(
    "Sample.Index", "Sample.Name", "Index", "Mass.Info",
    "Component.Name", # needed to get reference standard identifier in tab 4
    "Retention.Time"  # force users to export retention time
  )

  ## Mandatory MassHunter columns (before running |load_masshunter|)
  mandatory_masshunter <- c(
    "Name", "Transition",
    "RT" # force users to export retention time
  )

  ## Mandatory MassLynx columns (before running |load_masslynx|)
  mandatory_masslynx <- c(
    "V1", "#", "Sample.Text", "Quan.Trace",
    "RT" # force users to export retention time
  )

  ## Get all file paths
  files <- unzip_files(filepath)

  ## Check column headers in each file
  for (i in seq_along(files)) {
    if (vendor == all_gui_radio_options()[1]) {
      df <- nb_import_labelled_file(files[i])
      colnames(df) <- gsub("\\s+", ".", colnames(df))
      if (!(all(mandatory_multiquant %in% colnames(df)))) {
        #return(
        #  paste(
        #    "Invalid MultiQuant file. Must contain the following columns:",
        #    "Sample Index, Sample Name, Index, Mass Info, Component Name,",
        #    "and Retention Time."
        #  )
        #)
        return(1L)
      }
    } else if (vendor == all_gui_radio_options()[2]) {
      df <- read.xlsx(filepath, startRow = 2L, rows = c(2:3))
      colnames(df) <- gsub("\\s", ".", colnames(df))
      if (!(all(mandatory_masshunter %in% colnames(df)))) {
        #return(
        #  paste(
        #    "Invalid MassHunter file. Must contain the following columns",
        #    "in the 2nd row header:",
        #    " Name, Transition, RT."
        #  )
        #)
        return(2L)
      }
    } else if (vendor == all_gui_radio_options()[3]) {
      df <- fread(filepath, header = TRUE, skip = 6L, nrows = 1L)
      colnames(df) <- gsub("\\s", ".", colnames(df))
      if (!(all(mandatory_masslynx %in% colnames(df)))) {
        #return(
        #  paste(
        #    "Invalid MassLynx file. Must contain the following columns",
        #    "under each 'compound' table:",
        #    "<1st column empty>, #, Sample Text, Quan Trace."
        #  )
        #)
        return(3L)
      }
    }
  }
  return(0L)
}

# CONVERTING VENDOR FILES TO BATL FORMAT ---------------------------------------------------
## Main function to handle the conversion based on the input filepath,
## the user-selected/predicted vendor
## training == TRUE is to make modifications specific to the construction of
## training data. When training == FALSE, this should reasonably convert files
## for tab 4
#' convert_to_batl_format
#'
#' @description Converts SRM/MRM quantification files into the BATL-specific
#' text file format. Works
#'
#' @usage
#' convert_to_batl_format(filepath, vendor, training)
#'
#' @param filepath Path to the file of interest. Supports a single file or
#' a .zip of many files (following the vendor-specific format below).
#'
#' @param vendor One of the following mass spectrometry vendors:
#' 'MultiQuant (SCIEX)', 'MassHunter (Agilent)' or 'MassLynx (Waters)'
#'
#' @param training TRUE or FALSE. TRUE indicates the file is converted
#' specifically to create a training set. FALSE indicates the file is converted
#' specifically to be annotated by the BATL model.
#'
#' @return
#' List of BATL-specific SRM/MRM quantification file data tables.
#'
#' @examples
#' \dontrun{
#' }
#'
#' @export convert_to_batl_format
#'
convert_to_batl_format <- function(filepath, vendor, training) {

  ## Error-checking
  if (missing(filepath)) {
    stop(
      paste(
        "Must specify the name of the input file to be converted.",
        "Ensure the path to that file is correct."
      )
    )
  }
  if (length(filepath) > 1) {
    stop("Must specify a single filepath and not a vector of multiple paths.")
  }
  if (!is.character(filepath)) {
    stop("The filepath must be a string.")
  }

  if (missing(training)) {
    training <- TRUE
  }
  if (length(training) > 1) {
    stop("training must be TRUE or FALSE")
  }
  if (!is.logical(training)) {
    stop("The training parameter must be TRUE or FALSE")
  }

  if (missing(vendor)) {
    stop(
      paste(
        "Must specify the vendor format of your input dataset. Options are:\n",
        "'MultiQuant' from SCIEX\n",
        "'MassHunter' from Agilent\n",
        "'MassLynx' from Waters"
      )
    )
  }

  if (length(vendor) > 1) {
    stop("Must select a single vendor.")
  }
  strings <- c(
    "MultiQuant", "MassHunter", "MassLynx",
    "MultiQuant (SCIEX)", "MassHunter (Agilent)", "MassLynx (Waters)")
  if (!(vendor %in% strings)) {
    stop(
      paste(
        "Must specify the vendor format of your input dataset. Options are:\n",
        "'MultiQuant' from SCIEX\n",
        "'MassHunter' from Agilent\n",
        "'MassLynx' from Waters"
      )
    )
  }

  ## Convert user input vendors into the actual strings
  if (vendor == "MultiQuant") {
    vendor <- "MultiQuant (SCIEX)"
  } else if (vendor == "MassHunter") {
    vendor <- "MassHunter (Agilent)"
  } else if (vendor == "MassLynx") {
    vendor <- "MassLynx (Waters)"
  }

  ## Get all file paths
  files <- unzip_files(filepath)

  ## Initialize output (format converted files)
  output <- vector("list", length = length(files))

  for (i in seq_along(files)) {
    if (vendor == all_gui_radio_options()[1]) {
      output[[i]] <- load_multiquant(files[i], training)
    } else if (vendor == all_gui_radio_options()[2]) {
      output[[i]] <- load_masshunter(files[i], training)
    } else if (vendor == all_gui_radio_options()[3]) {
      output[[i]] <- load_masslynx(files[i], training)
    }
  }
  return(output)
}

## Subroutine to load MultiQuant files (will move later to the core BATL package)
load_multiquant <- function(filepath, training) {

  ## Load file
  output <- nb_import_labelled_file(filepath)
  #colnames(output) <- gsub("\\s+", ".", colnames(output), perl = TRUE)

  if (training == TRUE) {
    output[, "Filename" := gsub("(.*\\/)", "", filepath, perl = TRUE)]
    setnames(
      output, "Lipid_identifier_MWBM", "Lipid_identifier", skip_absent = TRUE)
    if (!("Lipid_identifier" %in% colnames(output))) {
      output[, "Lipid_identifier" := NA_character_]
    }
    #cols_of_interest <- c(
    #  "Filename", "Sample Index", "Sample Name", "Index", "Mass Info")
    #cols_rest <- colnames(output)[
    #  which(!(colnames(output) %in% c(
    #    cols_of_interest, "Component Name", "Lipid_identifier")))]
    setcolorder(
      output,
      unique(c("Filename", colnames(output), "Lipid_identifier"))
    )

    if ("Insource_annotation" %in% colnames(output)) {
      output[, "Insource_annotation" := NULL]
    }
  }

  return(output)
}

## Subroutine to load MassHunter files (will move later to the core BATL package)
## Works on spreadsheet but the commented out fread() code will work properly
## with text files
load_masshunter <- function(filepath, training) {

  ## Load spreadsheet
  df <- as.data.frame(fread(filepath, header = TRUE))
  #df[1, ] <- gsub("\\s+", ".", df[1, ], perl = TRUE)

  ## Determine the name and sample indices (1st header)
  idx_samples <- colnames(df)[!grepl("^V[0-9]+", colnames(df), perl = TRUE)]
  idx_samples <- idx_samples[2:length(idx_samples)]
  idx_samples <- which(colnames(df) %in% idx_samples)
  sample_names <- colnames(df)[idx_samples]

  ## Get the name of the first subheader for the first compound
  first_subheader <- df[1, idx_samples[1]]

  ## Get the name of the last subheader for the first compound
  if (length(idx_samples) == 1) {
    last_subheader <- df[1, ncol(df)]
  } else {
    last_subheader <- df[1, idx_samples[2] - 1]
  }

  ## Get name of the last column subheader for the sample info before compounds
  sample_subheader <- df[1, idx_samples[1] - 1]

  ## Load file again but with second header
  #df <- read.xlsx(filepath, startRow = 2L)
  df <- as.data.frame(fread(filepath, header = TRUE, skip = 1L))
  #colnames(df) <- df[1, ] <- gsub("\\s+", ".", colnames(df), perl = TRUE)

  ## Get number of sample columns before compounds
  cols_before_compound <- which(colnames(df) == sample_subheader)[1]

  ## Get number of columns for each compound
  cols_per_compound <- which(colnames(df) == last_subheader)[1] -
    which(colnames(df) == first_subheader)[1] + 1

  ## Get column method columns of interest
  name_idx <- which(colnames(df)[1:cols_per_compound] == "Name")
  transition_idx <- which(colnames(df)[1:cols_per_compound] == "Transition")

  ## Initialize list of output compounds and fill
  output <- vector("list", length = length(idx_samples))
  for (i in seq_along(idx_samples)) {
    row_start <- (i - 1) * cols_per_compound + cols_before_compound + 1
    row_end <- row_start + cols_per_compound - 1

    output[[i]] <- fread(
      filepath,
      skip = 1L,
      select = c(
        name_idx, transition_idx,
        row_start:row_end
      )
    )
    output[[i]] <- as.data.table(output[[i]])
    output[[i]][, "Sample Name" := sample_names[i]]
    output[[i]][, "Sample Index" := i]
  }

  ## Vertical concatenation of compound-specific data tables
  output <- do.call("rbind", output)

  ## Rename/modify specific columns to adhere to BATL format
  duplicated_cols <- colnames(output)[which(duplicated(colnames(output)))]
  for (i in seq_along(duplicated_cols)) {
    colnames(output)[which(colnames(output) == duplicated_cols[i])[1]] <- paste(
      "Compound Method ", duplicated_cols[i], sep = "")
  }
  setnames(output, "Name", "Component Name")
  setnames(output, "Transition", "Mass Info")
  output[, "Mass Info" := gsub("->", "/", `Mass Info`, perl = FALSE)]
  setkey(output, "Sample Index", "Sample Name")
  output[, "Index" := .I]
  if (training == TRUE) {
    output[, "Filename" := gsub("(.*\\/)", "", filepath, perl = TRUE)]
    if (!("Lipid_identifier" %in% colnames(output))) {
      output[, "Lipid_identifier" := NA_character_]
    }
    cols_of_interest <- c("Filename", "Sample Index", "Sample Name", "Index", "Component Name")
  } else {
    cols_of_interest <- c("Sample Index", "Sample Name", "Index", "Component Name")
  }

  cols_rest <- colnames(output)[
    which(!(colnames(output) %in% c(cols_of_interest, "Lipid_identifier")))]

  setcolorder(
    output,
    c(cols_of_interest, cols_rest, "Lipid_identifier"))

  ## Remove qualifier MRM transitions, if there are any
  output[, "Mass Info" := gsub(",.*", "", `Mass Info`, perl = TRUE)]

  return(output)
}

## Subroutine to load MassLynx files (will move later to the core BATL package)
load_masslynx <- function(filepath, training) {

  ## Determine the number of compounds in the file
  compound_subheader <- c()
  connection <-file(filepath, "r")
  while (TRUE) {
    line <- readLines(connection, n = 1)
    if (length(line) == 0) {
      break
    }
    if (grepl("^Printed", line, perl = TRUE)) {
      filename <- line
    }
    if (grepl("^Compound\\s[0-9]+:", line, perl = TRUE)) {
      compound_subheader <- c(compound_subheader, line)
    }
  }
  close(connection)
  num_compounds <- compound_subheader[length(compound_subheader)]
  num_compounds <- length(compound_subheader)

  ## Determine the number of samples across all compounds
  connection <-file(filepath, "r")
  i <- 0
  whitespace_idx <- c()
  while (TRUE) {
    line <- readLines(connection, n = 1)
    i <- i + 1
    if (is.character(line) && length(line) == 0 && is.null(attr(line, "name"))) {
      break
    } else if (line == "") {
      whitespace_idx <- c(whitespace_idx, i)
    }
  }
  close(connection)

  ## Paired indices
  ## Skip odd index to get data frame header
  ## Even index minus 1 to get end of data frame rows
  whitespace_idx <- whitespace_idx[3:length(whitespace_idx)]

  ## Initialize list of output compounds
  output <- vector("list", length = num_compounds)

  ## Determine which rows to skip for each compound and number of rows to read
  for (i in seq_len(num_compounds)) {

    skip_start <- whitespace_idx[(i * 2 - 1)]
    row_end <- whitespace_idx[(i * 2)]
    num_rows <- row_end - skip_start - 2

    output[[i]] <- fread(filepath, header = TRUE, skip = skip_start, nrows = num_rows)

    ## Add and rename the following headers and modify value formats
    colnames(output[[i]]) <- gsub("\\s+", ".", colnames(output[[i]]))
    setnames(output[[i]], "V1", "Sample Index")
    setnames(output[[i]], "#", "Index")
    setnames(output[[i]], "Sample.Text", "Sample Name")
    setnames(output[[i]], "Quan.Trace", "Mass Info")
    output[[i]][, "Mass Info" := gsub(">", "/", `Mass Info`, perl = FALSE)]
    output[[i]][, "Component Name" := trimws(
      gsub("Compound\\s[0-9]+:", "", compound_subheader[i]))]

  }

  ## Vertical concatenation of compound-specific data tables
  output <- do.call("rbind", output)

  ## Set sample index based on the sample name
  output[, "Sample Index" := .GRP, by = "Sample Name"]

  ## Make 'Index' span across all samples and create 'Filename' column
  setkey(output, "Sample Index")
  output[, "Index" := .I]

  if (training == TRUE) {
    output[, "Filename" := gsub("(.*\\/)", "", filepath, perl = TRUE)]
    if (!("Lipid_identifier" %in% colnames(output))) {
      output[, "Lipid_identifier" := NA_character_]
    }
    cols_of_interest <- c(
      "Filename", "Sample Index", "Sample Name", "Index", "Component Name",
      "Mass Info")
    cols_rest <- colnames(output)[
      which(!(colnames(output) %in% c(
        cols_of_interest, "Lipid_identifier")))]
    setcolorder(
      output,
      c(cols_of_interest, cols_rest, "Lipid_identifier"))
  }

  return(output)
}

# SANITIZING TAB 2 INPUT FILES  =================================
## Outputting specifc errors for tab 2 BATL-specific file upload
## Please replace the return statements with the uncommented text
## (or however you need to do so to get the popup messages working)
#' sanitize_training_inputs
#'
#' @export sanitize_training_inputs
#'
sanitize_training_inputs <- function(file) {

  ## File columns required for constructing training set
  mandatory <- c(
    "Sample.Index",
    "Sample.Name",
    "Index",
    "Mass.Info",
    "Component.Name"
  )
  ## One of the following must be present
  mandatory_retention <- c("Retention.Time", "RT")
  mandatory_identifier <- c("Lipid_identifier", "Lipid_identifier_MWBM")

  ## Unzip file if necessary
  files <- unzip_files(file)

  ## Check file extension
  for (i in seq_along(files)) {
    if (grepl(".txt$", files[i], perl = TRUE) == FALSE) {
      #return(
      #  paste(
      #    "Uploaded file or files in .zip must end with a .txt extension."
      #  )
      #)
      return(1L) # validation error message for incorrect file extension
    }
  }

  ## Check file columns
  all_columns <- vector("list", length = length(files))
  for (i in seq_along(files)) {
    df <- nb_import_labelled_file(files[i])
    colnames(df) <- gsub("\\s+", ".", colnames(df))
    all_columns[[i]] <- colnames(df)
    all_columns[[i]] <- all_columns[[i]][
      !(all_columns[[i]] %in% mandatory_identifier)]
    if (!(all(mandatory %in% colnames(df)))) {
      #return(
      #  paste(
      #    "The following columns must be present in your uploaded files:\n",
      #    "Sample.Index, Sample.Name, Index, Mass.Info,",
      #    "Component.Name, Retention.Time or RT, and either",
      #    "Lipid_identifier, or Lipid_identifier_MWBM."
      #  )
      #)
      return(2L) # validation error message for missing columns
    }
    if (!(any(mandatory_retention %in% colnames(df)))) {
      #return(
      #  paste(
      #    "The following column must be present in your uploaded files:\n",
      #    "Retention.Time (MultiQuant), or RT (MassHunter/MassLynx)."
      #  )
      #)
      return(3L) # validation error for missing retention time column
    }
    if (!any(mandatory_identifier %in% colnames(df))) {
      #paste(
      #  "The following column must be present in your uploaded files:\n",
      #  "Lipid_identifier, or Lipid_identifier_MWBM. Please ensure your",
      #  "SRM/MRM quantification files are labelled."
      #)
      return(4L) # validation error for missing lipid identifier column
    }
  }

  ## Check Lipid_identifier/Lipid_identifier_MWBM column is not all NA
  for (i in seq_along(files)) {
    df <- nb_import_labelled_file(files[i])
    if (mandatory_identifier[1] %in% colnames(df)) {
      if (all(is.na(df$Lipid_identifier))) {
        #return(
        #  paste(
        #    "The Lipid_identifier/Lipid_identifier_column has not been",
        #    "filled out."
        #  )
        #)
        return(5L) # validation error that lipid identifiers are not filled out
      }
    }
    if (mandatory_identifier[2] %in% colnames(df)) {
      if (all(is.na(df$Lipid_identifier_MWBM))) {
        #return(
        #  paste(
        #    "The Lipid_identifier/Lipid_identifier_column has not been",
        #    "filled out."
        #  )
        #)
        return(5L) # validation error that lipid identifiers are not filled out
      }
    }
  }

  ## Check for the same number of columns and same column names
  for (i in seq_along(all_columns)) {
    intersect_length <- length(intersect(all_columns[[1]], all_columns[[i]]))
    if (intersect_length != length(all_columns[[1]])) {
      #paste(
      #  "All files must contain the exact same number of columns with",
      #  "the exact same names."
      #)
      return(6L)
    }
  }

  return(0L)
}

# GET CORE FEATURE NAMES FROM VENDOR FORMAT ---------------------------------------------------
## Decision to never modify the feature names present in the user samples
## (Most of the other columns being renamed are easy to understand like
## Sample Name, Transition/Mass Info)
#' list_core_features
#'
#' @export list_core_features
#'
list_core_features <- function(filepath) {

  files <- unzip_files(filepath)
  df <- nb_import_labelled_file(files[1])

  ## All possible features in the GUI across all vendors
  max_core_features <- list(
    rt = c(
      "Retention time",
      "Relative retention time",
      "Subtracted retention time"
    ),
    area = "Relative area",
    height = "Relative height",
    fwhm = "Full width at half maximum amplitude",
    tailing = "Tailing factor",
    asymm = "Asymmetry factor"
  )

  ## MultiQuant-specific core features
  if ("Retention.Time" %in% colnames(df)) {

    find_features <- c(
      "Retention.Time",
      "Area",
      "Height",
      "Width.at.50%",
      "Tailing.Factor",
      "Asymmetry.Factor"
    )
  } else { ## Determine whether the file is from MassHunter or MassLynx
    find_features <- c(
      "RT",
      "Area",
      "Height",
      "FWHM",
      "Tailing.Factor",
      "Asymmetry.Factor"
    )
  }

  present_features <- find_features %in% colnames(df)
  gui_core_features <- unlist(
    max_core_features[present_features], use.names = FALSE)

  return(gui_core_features)
}

# UPDATE CORE FEATURES ---------------------------------------------------
#' update_core_features
#'
#' @export update_core_features
#'
update_core_features <- function(gui_core_features, filepath) {
  files <- unzip_files(filepath)
  df <- nb_import_labelled_file(files[1])

  if ("Retention.Time" %in% colnames(df)) {
    all_core <- list(
      `Retention time` = "Retention.Time",
      `Relative retention time` = "Relative.RT",
      `Subtracted retention time` = "Subtracted.RT",
      `Relative area` = "Area",
      `Relative height` = "Height",
      `Full width at half maximum amplitude` = "Width.at.50%",
      `Tailing factor` = "Tailing.Factor",
      `Asymmetry factor` = "Asymmetry.Factor"
    )
    return(as.character(all_core[match(gui_core_features, names(all_core))]))
  } else if ("RT" %in% colnames(df)) {
    all_core <- list(
      `Retention time` = "RT",
      `Relative retention time` = "Relative.RT",
      `Subtracted retention time` = "Subtracted.RT",
      `Relative area` = "Area",
      `Relative height` = "Height",
      `Full width at half maximum amplitude` = "FWHM",
      `Tailing factor` = "Tailing.Factor",
      `Asymmetry factor` = "Asymmetry.Factor"
    )
    return(as.character(all_core[match(gui_core_features, names(all_core))]))
  }
}

# LIST ALL CUSTOM FEATURES ---------------------------------------------------
## These features are ones that are not hard-coded blacklisted
## These features are the remaining columns in the user's uploaded file(s)
#' list_custom_features
#'
#' @export list_custom_features
#'
list_custom_features <- function(filepath) {

  ## Load first file (error-checking already confirms the columns are the same)
  files <- unzip_files(filepath)
  df <- nb_import_labelled_file(files[1])

  ## Core features (across the different vendors); certain features blacklisted
  all_core_features <- c(
    "Retention.Time",
    "Relative.RT", "RRT", # prevent user from using relative RT calculated by themselves
    "Area", "Area.Ratio", "Corrected.Area", # prevent user from selecting any area-based feature
    "Height", "Height.Ratio", "Corrected.Height", # prevent user from selecting any height-based feature
    "Width.at.50%", "FWHM",
    "Tailing.Factor",
    "Asymmetry.Factor"
  )

  ## Non-feature columns to avoid
  avoid_cols <- c(
    "Filename",
    "Sample.Index",
    "Sample.Name",
    "Index",
    "Mass.Info",
    "Lipid_identifier"
  )

  features <- colnames(df)[unlist(lapply(df, is.numeric))]
  features <- features[!(features %in% c(all_core_features, avoid_cols))]

  return(features)
}

# SANITZING CUSTOM FEATURES ------------------------------------------------
## Ensuring any selected custom feature must be numeric
#' sanitize_custom_feature
#'
#' @export sanitize_custom_feature
#'
sanitize_custom_feature <- function(filepath, custom_features) {

  files <- unzip_files(filepath)
  df <- nb_import_labelled_file(files[1])

  for (i in seq_along(custom_features)) {

    vals <- df[, custom_features[i], with = FALSE]
    vals <- unique(unlist(vals))
    if (!is.numeric(vals)) {
      #return(
      #  paste(
      #    "One or more custom features is not numeric."
      #  )
      #)
      return(1L) # validation error message for non-numeric feature
    }
  }

  return(0L)
}

# GET PERMISSIBLE REFERENCE STANDARD IDENTIFIERS ------------------------------------------------
## Only shows reference standards that are detected in all uploaded samples
## This function is only run when any of the 4 features requiring reference
## standard normalization are selected
#' permissible_reference_standard
#'
#' @export permissible_reference_standard
#'
permissible_reference_standard <- function(filepath) {

  ## Get all file paths
  files <- unzip_files(filepath)

  ## Initialize output (format converted files)
  output <- vector("list", length = length(files))

  ## Bind all files together (they should all have the same columns)
  for (i in seq_along(files)) {
    output[[i]] <- nb_import_labelled_file(files[i])
    colnames(output[[i]]) <- gsub("\\s+", ".", colnames(output[[i]]))
    setnames(
      output[[i]],
      "Lipid_identifier_MWBM",
      "Lipid_identifier",
      skip_absent = TRUE)

    if (!("Filename" %in% colnames(output[[i]]))) {
      temp_filename <- gsub("(.*\\/)", "", files[i], perl = TRUE)
      output[[i]] <- cbind(
        data.table(Filename = rep(temp_filename[i], times = nrow(output[[i]]))),
        output[[i]])
    }
  }
  output <- do.call("rbind", output)

  ## Get all lipid identifiers that are present in all samples
  output <- output[!is.na(Lipid_identifier)]
  output <- output[!(Lipid_identifier %in% c("", "UNASSIGNED"))]

  ## Find max number of samples and number of times each lipid identifier is
  ## observed
  id_count <- table(output[, Lipid_identifier])
  num_samples <- nrow(unique(output, by = c("Filename", "Sample.Index", "Sample.Name")))

  return(names(which(id_count == num_samples)))
}

# GENERATE THE TRAINING SET ------------------------------------------------
## Will move all functions in this section to the core BATL package later

## Wrapper to find the column indices in df based on column names in keep_cols
get_col_idx <- function(df, keep_cols) {
  return(which(colnames(df) %in% keep_cols))
}

## Finds the largest RT value in the concatenated training set and rounds to the
## nearest 'to'. Ex. x=43, to=10. round_up(x, to) = 50
round_up <- function(x, to) {
  return(ceiling(x / to) * to)
}

## Wrapper to get the maximum retention time used for the subtracted RT constant
compute_subtracted_rt <- function(df_list) {
  max_rt <- 0
  for (i in seq_along(df_list)) {
    if ("Retention.Time" %in% colnames(df_list[[i]])) {
      max_rt <- max(max_rt, df_list[[i]][, Retention.Time], na.rm = TRUE)
    } else if ("RT" %in% colnames(df_list[[i]])) {
      max_rt <- max(max_rt, df_list[[i]][, RT], na.rm = TRUE)
    }
  }
  return(round_up(max_rt, 10))
}


## Concatenate all of the individual files together, selecting for the
## desired features and/or calculating the ones that require normalization
## Assumes all files have the same column names and number of columns from
## previous error checking
#' generate_training_set
#'
#' @export generate_training_set
#'
generate_training_set <- function(
  filepath, core_features, custom_features,
  is_identifier,
  exceptions,
  ...) {

  params <- list(...)
  if ("shiny" %in% names(params)) {
    shiny <- TRUE
  } else {
    shiny <- FALSE
  }

  ## Keep retention time features anyways
  keep_rt <- c("Retention Time", "RT")

  ## Features that require normalization
  fnorm <- c("Area", "Height", "Relative RT", "Subtracted RT")

  ## Unzip files if necessary and load all datasets into a list
  files <- unzip_files(filepath)
  all_files <- vector("list", length = length(files))
  for (i in 1:length(all_files)) {
    all_files[[i]] <- nb_import_labelled_file(files[i])
    setnames(
      all_files[[i]],
      "Lipid_identifier_MWBM", "Lipid_identifier", skip_absent = TRUE)
  }

  ## Convert spaces to period for custom features (for data.table support) # might not be needed anymore
  custom_features <- gsub("\\s+", ".", custom_features, perl = TRUE)

  ## Mandatory columns in this order
  keep_base <- c(
    "Filename",
    "Sample Index",
    "Sample Name",
    "Index",
    "Mass Info",
    "Component Name")

  ## Core features first then append custom features if there are any
  keep_features <- c(core_features, custom_features)

  ## Lipid identifier for each peak
  keep_identifier <- "Lipid_identifier"

  ## Get subtracted retention time constant from all input file
  subtract_constant <- compute_subtracted_rt(all_files)

  ## Features present in file that require normalization
  to_normalize <- fnorm[fnorm %in% core_features]

  for (i in seq_along(all_files)) {

    ## Get indices of all columns to keep
    keep_base_idx <- get_col_idx(all_files[[i]], keep_base)
    keep_features_idx <- get_col_idx(all_files[[i]], keep_features)
    keep_rt_idx <- get_col_idx(all_files[[i]], keep_rt)
    setnames(
      all_files[[i]],
      "Lipid_identifier_MWBM",
      "Lipid_identifier",
      skip_absent = TRUE)
    keep_identifier_idx <- get_col_idx(all_files[[i]], keep_identifier)
    keep_all_idx <- unique(
      c(keep_base_idx, keep_identifier_idx, keep_features_idx, keep_rt_idx))

    ## Keep columns of interest by reference
    all_files[[i]] <- all_files[[i]][, unique(keep_all_idx), with = FALSE]

    ## Update the index of the retention time column now that dimensions changed
    keep_rt_idx <- get_col_idx(all_files[[i]], keep_rt)
    rt_name <- colnames(all_files[[i]])[keep_rt_idx]

    ## Clean the training set for duplicates, empty transitions, and UNASSIGNED
    all_files[[i]] <- unique(
      all_files[[i]],
      by = c(
        "Filename",
        "Sample Index",
        "Sample Name",
        "Mass Info",
        "Lipid_identifier"))
    all_files[[i]] <- all_files[[i]][
      !(Lipid_identifier %in% c("UNASSIGNED", ""))]

    setnames(all_files[[i]], rt_name, "Feature_check_na")
    all_files[[i]] <- all_files[[i]][!is.na(Feature_check_na)]
    setnames(all_files[[i]], "Feature_check_na", rt_name)

    ## Remove exceptions based on Mass.Info
    all_files[[i]] <- all_files[[i]][!(Mass.Info %in% exceptions)]

    ## Compute the normalized features and add them as columns
    all_files[[i]] <- nb_label_peaks_normalize_file(
      loaded = all_files[[i]],
      features = to_normalize,
      fnorm = to_normalize,
      qstandard = is_identifier,
      qstandard_col = "Lipid_identifier",
      subtract_constant = subtract_constant)
  }

  ## Merge all files and set column orders (base, identifier, features)
  merged <- do.call("rbind", all_files)

  ## Clean the training set again for duplicates across individual files
  merged <- unique(
    merged,
    by = c(
      "Filename",
      "Sample Index",
      "Sample Name",
      "Mass Info",
      "Lipid_identifier"))

  ## Remove retention time feature (however named) if it was not a core feature
  if (!any(keep_rt %in% keep_features)) {
    keep_rt_idx <- get_col_idx(merged, keep_rt)
    merged[, colnames(merged)[keep_rt_idx] := NULL]
  }

  ## If subtracted retention time is a core feature, output the constant
  ## Else, set the constant to NULL
  if ("Subtracted RT" %in% keep_features & shiny == TRUE) {
    return(list(constant = subtract_constant, training_set = merged))
  } else {
    return(list(constant = NULL, training_set = merged))
  }
}

# GET COMPONENT NAME OF SELECTED REFERENCE STANDRD ------------------------------------------------
## Error-checking to determine a unique component name corresponding to the
## selected reference standard lipid identifier
## Remove the integer returns and uncomment the string returns (modify at
## will to get the error checking popups working)
#' sanitize_reference_component
#'
#' @export sanitize_reference_component
#'
sanitize_reference_component <- function(training_set, reference_standard) {
  component_names <- training_set[
    Lipid_identifier == reference_standard
    , Component.Name]

  ## Check to ensure no component names are blank (not filled out)
  if (any(is.na(component_names))) {
    #return(
    #  paste(
    #    "The 'Lipid_identifier' of your selected reference standard is:",
    #    reference_standard, ".",
    #    "Please ensure that the corresponding row-values under the",
    #    "'Component.Name' of this",
    #    "standard is filled out in the 'Component.Name' column in your",
    #    "BATL-converted, SRM/MRM peak quantification files."
    #  )
    #)
    return(1L)
  }
  ## Check to ensure the same component name is used to describe the same
  ## reference standard
  if (length(unique(component_names)) > 1)  {
    #return(
    #  paste(
    #    "The 'Lipid_identifier' of your selected reference standard is:",
    #    reference_standard, ".",
    #    "Please ensure this standard corresponds to a single 'Component.Name'",
    #    "in your BATL-converted, SRM/MRM peak quantification files.",
    #    "Currently,", reference_standard, "is labelled as",
    #    paste(unique(component_names), collapse = ", "),
    #    "under the 'Component.Name' column."
    #  )
    #)
    return(2L)
  }
  return(0L)
}

## Gets the component name of the reference standard
#' get_reference_component
#'
#' @export get_reference_component
#'
get_reference_component <- function(training_set, reference_standard) {

  component_names <- training_set[
    Lipid_identifier == reference_standard
    , Component.Name]
  return(unique(component_names))
}

## Remove the component name column from the training set for subsequent tabs
## This is to prevent users from being confused about seeing a Component.Name
## and Lipid_identifier column in their training set
#' remove_component_name
#'
#' @export remove_component_name
#'
remove_component_name <- function(training_set) {
  return(training_set[, "Component.Name" := NULL])
}

## Get folds for leave-one-out cross validation model building
#' get_folds
#'
#' @export get_folds
#'
get_folds <- function(training_set) {
  return(length(training_set[, unique(Sample.Name)]))
}

# SANITIZE TAB 4 INPUTS ------------------------------------------------
## More 'lazy' error checking except for a specific check for the file extension
#' sanitize_input_model
#'
#' @export sanitize_input_model
#'
sanitize_input_model <- function(model) {

  if (grepl(".txt$", model, perl = TRUE) == FALSE) {
    #x <- paste(
    #  "Uploaded model file must end with a .txt extension."
    #)
    x <- 1L
  } else {
    x <- tryCatch({
      nb_import_model(model)
      #paste(
      #  "The file you uploaded is not recognized as a valid BATL model file."
      #)
      0L
    },
    error = function(e) {
      2L
    })
  }
  return(x)
}

## Extract desired meta info row based on string from the model model_meta_info
#' extract_model_meta_info
#'
#' @export extract_model_meta_info
#'
extract_model_meta_info <- function(model, string) {

  ## Subset for the model meta info
  model_meta_info <- model$Meta_information

  ## Extract decision string
  row_idx <- grep(paste0("# ", string), model_meta_info)
  row_string <- model_meta_info[row_idx]

  ## Convert to vector
  row_string <- gsub(".*<-", "", row_string)
  row_string <- gsub(".*\\(", "", row_string)
  row_string <- gsub("\\)*", "", row_string)
  row_string <- trimws(row_string)
  row_string <- strsplit(row_string, ",")[[1]]

  return(row_string)
}

## Check to ensure unlabelled quantification files are truly unlabelled
## with no lipid identities under the Lipid_identifier_MWBM columns
#' check_unlabelled_file
#'
#' @export check_unlabelled_file
#'
check_unlabelled_file <- function(peak_file_list) {

  for (i in seq_along(peak_file_list)) {
    if ("Lipid_identifier_MWBM" %in% colnames(peak_file_list[[i]])) {
      if (!all(is.na(peak_file_list[[i]][, Lipid_identifier_MWBM]))) {
        return(1L) # error
      }
    }
  }
  return(0L)
}

## Check that the component name in the model is present in all of the samples
## the user would like to assign annotations to
#' sanitize_component_name_samples
#'
#' @export sanitize_component_name_samples
#
sanitize_component_name_samples <- function(peak_list, component_name) {

  for (i in seq_along(peak_list)) {
    num_samples <- nrow(unique(
      peak_list[[i]], by = c("Sample.Index", "Sample.Name")))
    num_component <- nrow(peak_list[[i]][Component.Name == component_name])

    if (num_samples != num_component) {
      #return(
      #  paste(
      #    "Some peaks have no matching reference standard for feature",
      #    "normalization. Please ensure that",
      #    component_name,
      #    "is detected",
      #    "in each of your samples you would like to annotate."
      #  )
      #)
      return(1L) # Error if the component name not found in all samples
    }
  }

  return(0L)
}
