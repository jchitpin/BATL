#' decision_mwbm
#'
#' @description Maximum weighted bipartite matching decision algorithm.
#' Maximizes the joint, log posterior probabilities of all candidate
#' assignments for all peaks at a given transition and sample run using the
#' push-relabel algorithm from the igraph package. \cr
#'
#' @usage
#' decision_mwbm(return)
#'
#' @param return Data table object of candidate assignments.
#'
#' @return
#' Boolean column indicating TRUE or FALSE lipid label assignments.
#'
#' @references \url{https://igraph.org/r/doc/matching.html}
#'
#' @importFrom data.table data.table
#' @importFrom igraph graph.data.frame max_bipartite_match V E
#'
#' @keywords internal

decision_mwbm <- function(return) {

    ## Null strategy to pass R CMD check
    Index <- Sample.Name <- Lipid_identifier <- NULL
    Posterior <- V <- Index_mwbm <- NULL
    E <- Posterior_mwbm <- Lipid_identifier_mwbm <- NULL
    Posterior_mwbm <- MWBM <- NULL
    graph.data.frame <- max_bipartite_match <- V1 <- NULL
    `V<-` <- `E<-` <- Sample.Index <- Concat_Sample_Index_Name <- NULL

    ## Maximum weighted bipartite matching for each run
    ## Only one possible testing (run) Lipid_identifier can match a single
    ## training Lipid_identifier. NAs can be produced if an MRM peak doesn't
    ## match anything in the training library.
    return[, "Index_mwbm" := paste(Index, Sample.Index, Sample.Name, sep = "_")]

    ## Second set of vertices
    return[
        , "Lipid_identifier_mwbm" := paste(
            Lipid_identifier, Sample.Index, Sample.Name, sep = "_")]

    ## Log transform posterior and add normalizing constant because maximum
    ## weighted bipartite matching can mess up with really small values and
    ## doesn't work well with negative values or infinities
    return[, "Posterior_mwbm" := log(Posterior)]

    ## Any -Inf is because a posterior = 0 so log(posterior) = -Inf
    ## We never assign labels with 0 posterior probabilities
    return[
        is.infinite(Posterior_mwbm) & Posterior_mwbm < 0
        , Posterior_mwbm := NA]

    ## Any +Inf posterior comes from the transition-specific posterior cutoff
    ## MWBM function does not work with Inf so substitute that with the greatest
    ## observed posterior probability in the table plus a constant so that we
    ## always choose to not assign a Lipid_identifier to these peak rows
    inf_replace <- return[
        !(is.infinite(Posterior_mwbm))
        , (max(abs(Posterior_mwbm), na.rm = TRUE))] + 1
    return[
        is.infinite(Posterior_mwbm) & Posterior_mwbm > 0
        , Posterior_mwbm := inf_replace]

    ## Linear shift all posterior probabilities greater than 0 because
    ## MWBM function doesn't work with negative weights
    return[
        , Posterior_mwbm := Posterior_mwbm + max(
            abs(Posterior_mwbm) + 1, na.rm = TRUE)
        , by = c("Sample.Index", "Sample.Name")]


    if (nrow(return[is.infinite(Posterior_mwbm) | Posterior_mwbm < 0]) > 0) {
        stop(paste0(
            "Posterior probabilities for maximum matching are",
            "infinite or less than 0. This is a bug to be fixed."))
    }

    ## Set Index_mwbm and Lipid_identifier_mwbm as the nodes
    setcolorder(
        return, c(
            seq((ncol(return) - 2), (ncol(return) - 1), by = 1),
            seq(1, (ncol(return) - 3), by = 1), ncol(return)))

    ## Loop over each sample running MWBM
    ## This is because the max_bipartite_match function hangs when the graph
    ## gets too large
    return[
        , "Concat_Sample_Index_Name" := paste(
            Sample.Index, "_____", Sample.Name, sep = "")]
    all_samples <- return[, unique(Concat_Sample_Index_Name)]
    return_all <- vector("list", length = length(all_samples))

    for (kBatch in seq_along(return_all)) {
        my_split <- all_samples[kBatch]
        my_index <- strsplit(my_split, "_____")[[1]]
        if (length(my_index) > 2) {
            stop("String splitting problem using 5 underscores.")
        }
        my_sample <- my_index[2]
        my_index <- my_index[1]
        return_sub <- return[
            Sample.Index == my_index & Sample.Name == my_sample]
        return_sub[, "Concat_Sample_Index_Name" := NULL]

        g <- graph.data.frame(return_sub, directed = TRUE)
        Vin  <- which(names(V(g)) %in% return_sub[, Index_mwbm])
        Vin  <- cbind(Vin, FALSE)
        Vout <- which(!(seq_len(length(V(g))) %in% Vin))
        Vout <- cbind(Vout, TRUE)
        Vall <- rbind(Vin, Vout)
        Vall <- Vall[order(Vall[, 1]), 2]
        V(g)$type <- as.logical(Vall)
        E(g)$weight <- as.numeric(return_sub[, Posterior_mwbm])
        mwbm <- max_bipartite_match(g)

        ## Only interested in matching 'Index' to 'Lipid_identifier'
        filter <- return_sub[, Index_mwbm]
        mwbm <- mwbm$matching[which(names(mwbm$matching) %in% filter)]
        mwbm <- data.table(
            Index_mwbm = names(mwbm),
            Lipid_identifier_mwbm = as.vector(mwbm),
            MWBM = "T")

        ## Assign label based on MWBM
        setkey(return_sub, Index_mwbm, Lipid_identifier_mwbm)
        setkey(mwbm, Index_mwbm, Lipid_identifier_mwbm)
        return_sub <- merge(return_sub, mwbm, all.x = TRUE)
        return_sub[, Index := as.integer(Index)]
        return_sub[
            , c(
                "Index_mwbm",
                "Lipid_identifier_mwbm",
                "Posterior_mwbm") := NULL]

        ## Anything NA after merging means MWBM did not assign the peak to that
        ## lipid so the decision is to not accept the assignment
        return_sub[is.na(MWBM), MWBM := "F"]
        return_sub[, MWBM := as.logical(MWBM)]
        ## An NA posterior probability means the peak was not detected
        return_sub[is.na(Posterior), MWBM := NA]
        ## Posterior of 0 means we fail to assign as well
        return_sub[Posterior == 0, MWBM := FALSE]

        ## Add to output list
        return_all[[kBatch]] <- return_sub
    }

    ## Unlist output list
    return <- do.call("rbind", return_all)
    setkey(return, Index, Lipid_identifier)

    ## Error checking such that we never assign 2 or more identities to a single
    ## peak. We are, however, allowed to assign no identities to a peak.
    val_check <- max(
        return[
            , sum(MWBM, na.rm = TRUE)
            , by = c("Sample.Index", "Sample.Name", "Index")][, V1])
    #return[
    #    , "Double_label" := sum(MWBM, na.rm = TRUE)
    #    , by = c("Sample.Index", "Sample.Name", "Index")]

    if (val_check > 1) {
        error_dt <- return[
            , sum(MWBM, na.rm = TRUE)
            , by = c("Sample.Index", "Sample.Name", "Index")][V1 > 1]
        error_info <- vector("character", length = nrow(error_dt))
        for (i in seq_along(error_info)) {
            error_info[i] <- paste0(error_dt[i, ], collapse = "\t")
        }
        error_info <- paste0("\n", error_info, collapse = "\n")
        stop(paste0(
            "MWBM is assigning 2 or more identities to a single peak. Check:\n",
            "Sample.Index \t Sample.Name \t Index\n",
            error_info))
    }
    return(return)
}
