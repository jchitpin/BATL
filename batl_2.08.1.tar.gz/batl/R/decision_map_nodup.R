#' decision_map_nodup
#'
#' @description Constrained maximum a posteriori decision algorithm. Assigns a
#' label based
#' on the greatest observed posterior probability. There is a constraint such
#' that the same lipid label can only be assigned once per sample run. This
#' function is slow because it orders all assignments by greatest posterior
#' probability and assigns the label at the top of the heap.
#'
#' @usage
#' decision_map_nodup(return)
#'
#' @param return Data table object of candidate assignments.
#'
#' @return
#' Boolean column indicating TRUE or FALSE lipid label assignments.
#'
#' @importFrom data.table .N
#' @importFrom utils tail
#'
#' @keywords internal

decision_map_nodup <- function(return) {

    ## Null strategy to pass R CMD check
    Posterior <- MAP_nodup <- Discard <- Index <- NULL
    Keep <- Keep2 <- Discard_index <- Discard_Lipid_identifier <- Skip <- NULL
    Lipid_identifier <- No_compare_index <- No_compare_Lipid_identifier <- NULL
    V1 <- NULL
    Lipid_identifier_NA <- Tie <- NULL


    ## Initialize output column
    return[, "MAP_nodup" := NA]

    ## Subset out unimportant rows in return table
    ## (Zero posterior if likelihood function * prior rounds to zero OR
    ## NA posterior if the peak was never even detected)
    return_NA <-  return[Posterior == 0 | is.na(Posterior)]

    ## Zero posterior means definitely do not assign
    return_NA[Posterior == 0, MAP_nodup := FALSE]

    ## NA posteriors mean no assignment
    return_NA[is.na(Posterior), MAP_nodup := NA_real_]

    ## Remaining data table of multiple assignments
    return_else <- return[!(is.na(Posterior)) & Posterior > 0]
    return_else[, "MAP_nodup" := FALSE]
    return_else[, "Discard" := NA]

    ## Special case where there is an exact posterior tie between the
    ## transition-specific cutoff and assignment; this should only happen
    ## during cross validation. The decision is to always choose the assignment
    ## because it is more probable that the sample size was low during cross
    ## validation.
    return[
        , "Lipid_identifier_NA" := grepl("NA_", Lipid_identifier, fixed = TRUE)]
    dups <- duplicated(
        return, by = c("Index", "Sample.Index", "Sample.Name", "Posterior"))
    return[, "Tie" := dups | c(tail(dups, -1), FALSE)]
    return[
        Lipid_identifier_NA == TRUE & Tie == TRUE
        , Posterior := Posterior - 1e-10]
    return[, c("Lipid_identifier_NA", "Tie") := NULL]

    ## New vectorized approach!
    ## Find top assignment across all sample runs, mark as TRUE.
    ## Find all other Lipid_identifiers/peak options and mark FALSE
    while (any(is.na(return_else[, Discard]))) {

        ## Assignments with greatest posteriors by sample run
        return_else[
            is.na(Discard)
            , "Keep" := max(Posterior, na.rm = TRUE)
            , by = c("Sample.Index", "Sample.Name")]
        return_else[, "Keep2" := ifelse(Keep == Posterior, TRUE, FALSE)]

        ## Find all instances of that assigned Lipid_identifier/peak
        return_else[Keep2 == TRUE, c("MAP_nodup", "Discard") := TRUE]
        return_else[Keep2 == TRUE, "Discard_index" := Index]
        return_else[
            Keep2 == TRUE, "Discard_Lipid_identifier" := Lipid_identifier]

        ## Skip column used to identify sample runs that containing all
        ## labelled peaks; these rows are excluded from subsequent assignments
        return_else[
            , "Skip" := ifelse(all(is.na(Discard_index)), TRUE, FALSE)
            , by = c("Sample.Index", "Sample.Name")]

        ## 'No_compare_index' column used to identify sample runs to not compare
        ## by shared index
        return_else[
            , "No_compare_index" := ifelse(
                all(is.na(Discard_index)), TRUE, FALSE)
            , by = c("Index", "Sample.Index", "Sample.Name")]

        ## 'No_compare_index' column used to identify sample runs to not compare
        ## by shared Lipid_identifier
        return_else[
            , "No_compare_Lipid_identifier" :=
                ifelse(all(is.na(Discard_index)), TRUE, FALSE)
            , by = c("Lipid_identifier", "Sample.Index", "Sample.Name")]

        ## Label indices by sample run that must be assigned FALSE
        return_else[
            Skip == FALSE & No_compare_index == FALSE
            , Discard_index := max(Discard_index, na.rm = TRUE)
            , by = c("Index", "Sample.Index", "Sample.Name")]

        ## Label Lipid_identifiers by sample run that must be assigned FALSE
        return_else[
            Skip == FALSE & No_compare_Lipid_identifier == FALSE
            , Discard_Lipid_identifier := max(
                Discard_Lipid_identifier, na.rm = TRUE)
            , by = c("Lipid_identifier", "Sample.Index", "Sample.Name")]

        ## Remove other candidate assignments with those Lipid_identifiers/peaks
        return_else[
            (
                Index == Discard_index |
                    Lipid_identifier == Discard_Lipid_identifier) &
                Keep2 == FALSE
            , c("MAP_nodup", "Discard") := FALSE]

        ## Drop columns
        return_else[
            , c("Keep",
                "Keep2",
                "Discard_index",
                "Discard_Lipid_identifier",
                "Skip",
                "No_compare_index",
                "No_compare_Lipid_identifier") := NULL]
    }

    ## Bind all rows together
    return_else[, c("Discard") := NULL]
    return <- rbind(return_else, return_NA)
    setkey(return, Index, Lipid_identifier)

    ## Error checking such that we never assign 2 or more identities to a single
    ## peak. We are, however, allowed to assign no identities to a peak.
    val_check <- max(
        return[
            , sum(MAP_nodup, na.rm = TRUE)
            , by = c("Sample.Index", "Sample.Name", "Index")][, V1])
    #return[
    #    , "Double_label" := sum(MAP_nodup, na.rm = TRUE)
    #    , by = c("Sample.Index", "Sample.Name", "Index")]

    if (val_check > 1) {
        stop("MAP_nodup is assigning 2 or more identities to a single peak.")
    }

    return(return)
}
