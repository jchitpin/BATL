#' Targeted lipidomics dataset of mouse temporcal cortex
#'
#' Toy SRM dataset.
#'
#'
#' @docType data
#'
#' @usage data(srm_tc)
#'
#'
#' @keywords datasets
#'
#' @examples
#' data(srm_tc)
#'
#'
"srm_tc"
