#' nb_import_labelled_file_list
#'
#' @description Wrapper function to import one or more tab-delimited, labelled
#' peak files as a list.
#'
#' @usage
#' nb_import_labelled_file_list(labelled_files)
#'
#' @param labelled_files Name and path of one or more labelled peak files
#' (ending in *.txt).
#'
#' @examples
#' \dontrun{
#' See batl-Introduction vignette for details
#' }
#'
#' @export nb_import_labelled_file_list
#'

nb_import_labelled_file_list <- function(labelled_files) {

    list_output <- vector("list", length = length(labelled_files))

    for (i in seq_along(labelled_files)) {
        list_output[[i]] <- fread(
            file = labelled_files[i],
            header = TRUE,
            sep = "\t",
            na.strings = "N/A",
            stringsAsFactors = FALSE)

        list_output[[i]] <- list_output[[i]][
            !(apply(is.na(list_output[[i]]) | list_output[[i]] == "", 1, all)),]
    }

    return(list_output)

}
